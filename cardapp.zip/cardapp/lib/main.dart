import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Custom Widget Demo',
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Color.fromARGB(255, 242, 239, 239),
        body: Center(
          child: ProfileCard(
            name: "Sandhya...",
            role: "I am a Flutter Developer",
            imageUrl: "https://i.pravatar.cc/300", // Sample avatar
            description: "Welcome to my 1st project",
          ),
        ),
      ),
    );
  }
}

// 🌈 Custom Widget
class ProfileCard extends StatelessWidget {
  final String name;
  final String role;
  final String imageUrl;
  final String description;

  const ProfileCard({
    super.key,
    required this.name,
    required this.role,
    required this.imageUrl,
    required this.description,
  });
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      margin: EdgeInsets.all(20),
      child: Container(
        padding: EdgeInsets.all(20),
        width: 300,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            colors: [
              Color.fromRGBO(206, 61, 211, 1),
              Color.fromARGB(255, 120, 153, 170),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              backgroundImage: AssetImage('assets/pic.jpeg'),
              radius: 70,
            ),
            Text(
              name,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 12, 12, 12),
              ),
            ),
            Text(
              role,
              style: TextStyle(
                fontSize: 16,
                color: const Color.fromARGB(179, 3, 3, 3),
              ),
            ),
            Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: const Color.fromARGB(179, 3, 3, 3),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Directing to message section')),
                );
              },
              icon: Icon(Icons.message),
              label: Text("Message"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Color(0xFF4CAF50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }
}